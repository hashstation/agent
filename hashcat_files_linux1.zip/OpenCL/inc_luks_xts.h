/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef INC_LUKS_XTS_H
#define INC_LUKS_XTS_H

DECLSPEC void xts_mul2 (PRIVATE_AS u32 *in, PRIVATE_AS u32 *out);

#endif // INC_LUKS_XTS_H
